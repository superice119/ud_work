# u-boot-mt7688
uboot for MT7688,also for widora :)
1.configure
make menuconfig
2.compile
make
3.clean
make clean

thanks to Manfeel、cleanwrt、Piotr Dymac、Adam Dunkels。
